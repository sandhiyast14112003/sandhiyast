class Student:
    def __init__(self, name, roll_number, cgpa):
        self.name = name
        self.roll_number = roll_number
        self.cgpa = cgpa

# Test data
students = [
    Student("John Doe", "101", 3.8),
    Student("Jane Doe", "102", 3.9),
    Student("Jim Doe", "103", 3.7),
    Student("Jill Doe", "104", 4.0)
]

sorted_students = sort_students(students)

# Print sorted students
for student in sorted_students:
    print(f"Name: {student.name}, Roll Number: {student.roll_number}, CGPA: {student.cgpa}")